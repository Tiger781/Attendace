
"use client";
import React from 'react';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarInset,
  SidebarTrigger,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/logo";
import { UserNav } from './user-nav';
import { usePathname } from 'next/navigation';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

type NavItem = {
    href: string;
    label: string;
    icon: LucideIcon;
};

type AppLayoutProps = {
    children: React.ReactNode;
    navItems: NavItem[];
    isHr?: boolean;
};

export function AppLayout({ children, navItems, isHr = false }: AppLayoutProps) {
    const pathname = usePathname();

    return (
        <SidebarProvider>
            <Sidebar>
                <SidebarHeader>
                    <Logo />
                </SidebarHeader>
                <SidebarContent>
                    <SidebarMenu>
                        {navItems.map((item) => (
                            <SidebarMenuItem key={item.href}>
                                <SidebarMenuButton 
                                    href={item.href} 
                                    isActive={pathname.startsWith(item.href)}
                                    tooltip={item.label}
                                    className="justify-start"
                                    asChild
                                >
                                    <a href={item.href}>
                                        <item.icon className="h-4 w-4" />
                                        <span>{item.label}</span>
                                    </a>
                                </SidebarMenuButton>
                            </SidebarMenuItem>
                        ))}
                    </SidebarMenu>
                </SidebarContent>
                <SidebarFooter>
                  <SidebarSeparator />
                   <SidebarMenu>
                        <SidebarMenuItem>
                            <UserNav isHr={isHr} isSidebar={true} />
                        </SidebarMenuItem>
                    </SidebarMenu>
                </SidebarFooter>
            </Sidebar>
            <SidebarInset>
                <header className={cn(
                    "flex items-center justify-between p-4 border-b h-16 sticky top-0 bg-background/95 backdrop-blur-sm z-10",
                    "md:justify-end"
                    )}>
                    <SidebarTrigger className="md:hidden" />
                    <UserNav isHr={isHr} />
                </header>
                <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                    {children}
                </main>
            </SidebarInset>
        </SidebarProvider>
    );
}
