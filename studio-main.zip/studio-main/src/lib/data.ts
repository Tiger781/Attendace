
import type { Employee, AttendanceRecord, Notification, AttendanceChangeRequest, AttendanceStatus } from '@/lib/types';

export const employees: Employee[] = [
  { id: 'EMP001', name: 'Alok Sharma', mobile: '9876543210', department: 'Logistics', location: 'Mumbai', status: 'Active', avatar: 'https://picsum.photos/seed/1/100/100' },
  { id: 'EMP002', name: 'Tabrej Shah', mobile: '9876543211', department: 'Operations', location: 'Delhi', status: 'Active', avatar: 'https://picsum.photos/seed/tabrej/100/100' },
  { id: 'EMP003', name: 'Rohan Gupta', mobile: '9876543212', department: 'Drivers', location: 'Mumbai', status: 'Active', avatar: 'https://picsum.photos/seed/3/100/100' },
  { id: 'EMP004', name: 'Sneha Patil', mobile: '9876543213', department: 'Warehouse', location: 'Bangalore', status: 'Inactive', avatar: 'https://picsum.photos/seed/4/100/100' },
  { id: 'EMP005', name: 'Vikram Rathore', mobile: '9876543214', department: 'Drivers', location: 'Delhi', status: 'Active', avatar: 'https://picsum.photos/seed/5/100/100' },
  { id: 'EMP006', name: 'Anjali Mehta', mobile: '9876543215', department: 'Logistics', location: 'Kolkata', status: 'Active', avatar: 'https://picsum.photos/seed/6/100/100' },
];

export const attendanceRecords: AttendanceRecord[] = [
  // Data for EMP002 (Tabrej Shah) for July
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-01', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-02', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-03', status: 'Absent' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-04', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-05', status: 'Half Day' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-06', status: 'Weekly Off' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-07', status: 'Weekly Off' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-08', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-09', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-10', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-11', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-12', status: 'Leave' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-13', status: 'Weekly Off' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-14', status: 'Weekly Off' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-15', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-16', status: 'Absent' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-17', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-18', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-19', status: 'Present' },
  
  // Data for other employees for a specific date (used in HR dashboard)
  { employeeId: 'EMP001', employeeName: 'Alok Sharma', date: '2024-07-23', status: 'Present' },
  { employeeId: 'EMP002', employeeName: 'Tabrej Shah', date: '2024-07-23', status: 'Leave' },
  { employeeId: 'EMP003', employeeName: 'Rohan Gupta', date: '2024-07-23', status: 'Absent' },
  { employeeId: 'EMP005', employeeName: 'Vikram Rathore', date: '2024-07-23', status: 'Weekly Off' },
  { employeeId: 'EMP006', employeeName: 'Anjali Mehta', date: '2024-07-23', status: 'Half Day' },
  
  // Add more data for the week of July 22-28 to make weekly view meaningful
  { employeeId: 'EMP001', employeeName: 'Alok Sharma', date: '2024-07-22', status: 'Present' },
  { employeeId: 'EMP003', employeeName: 'Rohan Gupta', date: '2024-07-22', status: 'Present' },
  { employeeId: 'EMP005', employeeName: 'Vikram Rathore', date: '2024-07-22', status: 'Present' },
  { employeeId: 'EMP006', employeeName: 'Anjali Mehta', date: '2024-07-22', status: 'Leave' },

  { employeeId: 'EMP001', employeeName: 'Alok Sharma', date: '2024-07-24', status: 'Present' },
  { employeeId: 'EMP003', employeeName: 'Rohan Gupta', date: '2024-07-24', status: 'Absent' },
  { employeeId: 'EMP005', employeeName: 'Vikram Rathore', date: '2024-07-24', status: 'Present' },
  { employeeId: 'EMP006', employeeName: 'Anjali Mehta', date: '2024-07-24', status: 'Present' },
];

export const notifications: Notification[] = [
    {
        id: 'NOTIF001',
        title: 'Salary Distribution Update for July 2024',
        message: 'Dear Employees, please note that the salary for July 2024 will be disbursed on the 31st of July. Please check your bank accounts. Contact HR for any discrepancies.',
        date: '2024-07-25T10:00:00Z',
    },
    {
        id: 'NOTIF002',
        title: 'Upcoming Public Holiday: Independence Day',
        message: 'The office will remain closed on August 15th, 2024, on account of Independence Day. We wish you all a happy holiday.',
        date: '2024-07-24T15:30:00Z',
    },
    {
        id: 'NOTIF003',
        title: 'New Health Insurance Policy',
        message: 'We are pleased to announce our new health insurance policy in partnership with ABC Insurance. Details have been sent to your email. The policy is effective from August 1st, 2024.',
        date: '2024-07-22T11:00:00Z',
    },
     {
        id: 'NOTIF004',
        title: 'Urgent: All-Hands Meeting Today',
        message: 'There will be a mandatory all-hands meeting today at 4:00 PM in the main conference room to discuss the Q3 roadmap. All employees are required to attend.',
        date: '2024-07-20T09:00:00Z',
    },
];

export const changeRequests: AttendanceChangeRequest[] = [
  {
    id: 'REQ001',
    employeeId: 'EMP003',
    employeeName: 'Rohan Gupta',
    date: '2024-07-23',
    oldStatus: 'Absent',
    newStatus: 'Leave',
    reason: 'Family emergency, was unable to inform earlier.',
  },
  {
    id: 'REQ002',
    employeeId: 'EMP006',
    employeeName: 'Anjali Mehta',
    date: '2024-07-23',
    oldStatus: 'Half Day',
    newStatus: 'Present',
    reason: 'Stayed late to complete the work, so it should be a full day.',
  },
  {
    id: 'REQ003',
    employeeId: 'EMP002',
    employeeName: 'Tabrej Shah',
    date: '2024-07-23',
    oldStatus: 'Leave',
    newStatus: 'Present',
    reason: 'My leave was cancelled, I was working.',
  },
];


export const getEmployeeData = (employeeId: string) => {
    const employeeRecords = attendanceRecords.filter(r => r.employeeId === employeeId);
    
    const data: {[key: string]: AttendanceStatus} = {};
    employeeRecords.forEach(rec => {
        data[rec.date] = rec.status;
    });
    
    return data;
}
