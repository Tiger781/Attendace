
export type Employee = {
    id: string;
    name: string;
    mobile: string;
    department: string;
    location: string;
    status: 'Active' | 'Inactive';
    avatar: string;
};

export type AttendanceStatus = 'Present' | 'Absent' | 'Half Day' | 'Leave' | 'Weekly Off';

export type AttendanceRecord = {
    employeeId: string;
    employeeName: string;
    date: string;
    status: AttendanceStatus;
};

export type Notification = {
    id: string;
    title: string;
    message: string;
    date: string;
};

export type AttendanceChangeRequest = {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  oldStatus: AttendanceStatus | 'N/A';
  newStatus: AttendanceStatus;
  reason: string;
};
