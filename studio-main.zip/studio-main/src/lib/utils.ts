
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { AttendanceStatus } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getStatusClasses(status?: AttendanceStatus | 'Active' | 'Inactive') {
  if (!status) return '';
  switch (status) {
    case 'Active':
        return 'border border-[#A5D6A7] bg-[#E8F5E9] text-[#2E7D32] dark:bg-green-950 dark:text-green-300 dark:border-green-800';
    case 'Inactive':
        return 'border border-[#F5C6CB] bg-[#FDECEA] text-[#C62828] dark:bg-red-950 dark:text-red-400 dark:border-red-800';
    case 'Present':
        return 'text-green-800 bg-green-50 border-green-200 dark:text-green-300 dark:bg-green-950 dark:border-green-800';
    case 'Absent':
        return 'text-red-800 bg-red-50 border-red-200 dark:text-red-400 dark:bg-red-950 dark:border-red-800';
    case 'Half Day':
        return 'text-orange-700 bg-orange-50 border-orange-200 dark:text-orange-400 dark:bg-orange-950 dark:border-orange-800';
    case 'Leave':
        return 'text-blue-700 bg-blue-50 border-blue-200 dark:text-blue-400 dark:bg-blue-950 dark:border-blue-800';
    case 'Weekly Off':
        return 'text-slate-700 bg-slate-100 border-slate-300 dark:text-slate-400 dark:bg-slate-800 dark:border-slate-700';
    default:
        return 'text-muted-foreground border-border bg-muted/50';
  }
}
