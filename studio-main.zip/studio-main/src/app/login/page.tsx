
"use client";

import Link from "next/link";
import * as React from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Logo } from "@/components/logo";
import { Skeleton } from "@/components/ui/skeleton";

function LoginPageSkeleton() {
    return (
        <div className="flex items-center justify-center min-h-screen p-4">
             <div className="w-full max-w-sm">
                <div className="flex justify-center mb-8">
                    <Logo />
                </div>
                <div className="w-full">
                    <div className="grid w-full grid-cols-2 h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground">
                       <Skeleton className="h-6 w-20 justify-self-center"/>
                       <Skeleton className="h-6 w-20 justify-self-center"/>
                    </div>
                    <div className="mt-6">
                        <Card>
                            <CardHeader>
                                <Skeleton className="h-6 w-3/4" />
                                <Skeleton className="h-4 w-full mt-1" />
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Skeleton className="h-4 w-20" />
                                        <Skeleton className="h-10 w-full" />
                                    </div>
                                    <div className="space-y-2">
                                        <Skeleton className="h-4 w-20" />
                                        <Skeleton className="h-10 w-full" />
                                    </div>
                                    <Skeleton className="h-10 w-full" />
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
                <div className="mt-6 text-center text-sm text-muted-foreground">
                    <Skeleton className="h-4 w-3/4 mx-auto" />
                </div>
             </div>
        </div>
    )
}

export default function LoginPage() {
  const [isClient, setIsClient] = React.useState(false);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return <LoginPageSkeleton />;
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <div className="w-full max-w-sm">
        <div className="flex justify-center mb-8">
            <Logo />
        </div>
        <Tabs defaultValue="employee" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="employee">Employee</TabsTrigger>
              <TabsTrigger value="hr">HR/Admin</TabsTrigger>
            </TabsList>
            <TabsContent value="employee" className="mt-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-xl">Employee Login</CardTitle>
                        <CardDescription>
                        Enter your credentials. Use EMP002 for Tabrej Shah's demo.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                      
                        <form className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="employee-id">Employee ID</Label>
                            <Input id="employee-id" placeholder="e.g., EMP002" required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="employee-password">Password</Label>
                            <Input id="employee-password" type="password" placeholder="Enter your password" required />
                          </div>
                          <Button type="submit" className="w-full" asChild>
                            <Link href="/employee/dashboard">Login as Employee</Link>
                          </Button>
                        </form>
                      
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="hr" className="mt-6">
                <Card>
                     <CardHeader>
                        <CardTitle className="text-xl">HR & Admin Login</CardTitle>
                        <CardDescription>
                        Sign in to manage employees and attendance.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                      
                        <form className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="admin-id">Admin ID or Email</Label>
                            <Input id="admin-id" placeholder="e.g., admin@attendhr.com" required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="admin-password">Password / OTP</Label>
                            <Input id="admin-password" type="password" required />
                          </div>
                          <Button type="submit" className="w-full" asChild>
                            <Link href="/hr/dashboard">Login as HR/Admin</Link>
                          </Button>
                        </form>
                      
                    </CardContent>
                </Card>
            </TabsContent>
        </Tabs>
        <div className="mt-6 text-center text-sm text-muted-foreground">
            Having trouble logging in?{" "}
            <Link href="#" className="underline text-primary hover:text-primary/90">
            Contact support
            </Link>
        </div>
      </div>
    </div>
  );
}
