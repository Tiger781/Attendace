"use client";

import { AppLayout } from "@/components/layout/app-layout";
import { LayoutDashboard, Users, CalendarCheck, Bell, User } from "lucide-react";

const navItems = [
    { href: "/hr/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/hr/employees", label: "Employees", icon: Users },
    { href: "/hr/attendance", label: "Attendance", icon: CalendarCheck },
    { href: "/hr/notifications", label: "Notifications", icon: Bell },
    { href: "/hr/profile", label: "Profile", icon: User },
];

export default function HrLayout({ children }: { children: React.ReactNode }) {
    return <AppLayout navItems={navItems} isHr={true}>{children}</AppLayout>;
}
