
"use client";

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Pen } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

function ProfileSkeleton() {
    return (
        <Card className="max-w-4xl mx-auto">
            <CardHeader>
                <Skeleton className="h-7 w-1/4" />
                <Skeleton className="h-4 w-1/2 mt-1" />
            </CardHeader>
            <form>
                <CardContent className="space-y-8">
                    <div className="flex items-center gap-6">
                        <Skeleton className="h-24 w-24 rounded-full border" />
                        <div className="space-y-2">
                            <Skeleton className="h-8 w-48" />
                            <Skeleton className="h-5 w-32" />
                        </div>
                    </div>
                    <Separator />
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-16" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-16" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-24" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-12" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                    </div>
                </CardContent>
                <CardFooter className="border-t pt-6">
                    <div className="flex justify-end gap-2 w-full">
                        <Skeleton className="h-10 w-24" />
                        <Skeleton className="h-10 w-32" />
                    </div>
                </CardFooter>
            </form>
        </Card>
    );
}


export default function HRProfilePage() {
  const [isClient, setIsClient] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const user = {
    name: 'Tabrej Shah',
    email: 'tabrej.admin@attendhr.com',
    avatar: 'https://picsum.photos/seed/hr/100/100',
    role: 'Administrator',
    id: 'ADMIN001'
  };

  const [name, setName] = React.useState(user.name);
  const [email, setEmail] = React.useState(user.email);

  const handleSaveChanges = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log("Saving HR Profile:", { name, email });
    toast({
        title: "Profile Updated",
        description: "Your administrator profile has been saved.",
    });
  };

  const handleCancel = () => {
    setName(user.name);
    setEmail(user.email);
    toast({
        title: "Changes Discarded",
    });
  };

  if (!isClient) {
    return <ProfileSkeleton />;
  }

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>My Profile</CardTitle>
        <CardDescription>
          Your administrator account details.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSaveChanges}>
        <CardContent className="space-y-8">
            <div className="flex items-center gap-6">
            <div className="relative">
                <Avatar className="h-24 w-24 border">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>TS</AvatarFallback>
                </Avatar>
                <Button variant="outline" size="icon" className="absolute -bottom-2 -right-2 rounded-full bg-background hover:bg-muted h-8 w-8">
                    <Pen className="h-4 w-4"/>
                    <span className="sr-only">Edit Profile Picture</span>
                </Button>
            </div>
            <div className="space-y-1">
                <h2 className="text-2xl font-bold tracking-tight">{user.name}</h2>
                <p className="text-muted-foreground">{user.role}</p>
            </div>
            </div>

            <Separator />

            <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
                <Label htmlFor="adminId">Admin ID</Label>
                <Input id="adminId" value={user.id} readOnly disabled />
            </div>
            <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Input id="role" value={user.role} readOnly disabled />
            </div>
            </div>

        </CardContent>
        <CardFooter className="border-t pt-6">
            <div className="flex justify-end gap-2 w-full">
                <Button type="button" variant="outline" onClick={handleCancel}>Cancel</Button>
                <Button type="submit">Save Changes</Button>
            </div>
        </CardFooter>
      </form>
    </Card>
  );
}
