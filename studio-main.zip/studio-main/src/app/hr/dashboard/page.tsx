
"use client"

import React from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ArrowRight, Users, UserCheck, UserX, CalendarOff, MailQuestion, Clock, CalendarClock } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn, getStatusClasses } from "@/lib/utils"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, isWithinInterval } from "date-fns"

import { employees, attendanceRecords as initialAttendance, changeRequests as initialRequests } from "@/lib/data"
import type { AttendanceRecord, AttendanceChangeRequest, AttendanceStatus } from "@/lib/types"
import { Skeleton } from "@/components/ui/skeleton"

function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="flex flex-wrap items-center justify-between gap-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-[250px]" />
      </div>

       <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7">
        {[...Array(7)].map((_, i) => (
            <Card key={i}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-4 rounded-sm" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-7 w-12 mb-1" />
                    <Skeleton className="h-3 w-16" />
                </CardContent>
            </Card>
        ))}
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-4 w-3/4 mt-2" />
          </CardHeader>
          <CardContent>
              <div className="rounded-md border">
              <Table>
                  <TableHeader>
                      <TableRow>
                          <TableHead><Skeleton className="h-5 w-24" /></TableHead>
                          <TableHead className="hidden md:table-cell"><Skeleton className="h-5 w-24" /></TableHead>
                          <TableHead className="text-right"><Skeleton className="h-5 w-20" /></TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {[...Array(3)].map((_, i) => (
                          <TableRow key={i}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                    <Skeleton className="h-9 w-9 rounded-full" />
                                    <Skeleton className="h-5 w-32" />
                                </div>
                              </TableCell>
                              <TableCell className="hidden md:table-cell"><Skeleton className="h-5 w-24" /></TableCell>
                              <TableCell className="text-right">
                                  <Skeleton className="h-6 w-20 rounded-full" />
                              </TableCell>
                          </TableRow>
                      ))}
                  </TableBody>
              </Table>
              </div>
          </CardContent>
        </Card>
        
        <Card>
            <CardHeader>
                <Skeleton className="h-6 w-1/3" />
                <Skeleton className="h-4 w-1/2 mt-2" />
            </CardHeader>
            <CardContent>
                <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                           <TableHead><Skeleton className="h-5 w-24" /></TableHead>
                            <TableHead className="hidden sm:table-cell"><Skeleton className="h-5 w-24" /></TableHead>
                            <TableHead><Skeleton className="h-5 w-48" /></TableHead>
                            <TableHead className="hidden lg:table-cell"><Skeleton className="h-5 w-32" /></TableHead>
                            <TableHead className="text-right"><Skeleton className="h-5 w-20" /></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                         {[...Array(2)].map((_, i) => (
                            <TableRow key={i}>
                                <TableCell>
                                    <Skeleton className="h-5 w-24" />
                                </TableCell>
                                <TableCell className="hidden sm:table-cell"><Skeleton className="h-5 w-24" /></TableCell>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <Skeleton className="h-6 w-16 rounded-full" />
                                        <Skeleton className="h-4 w-4" />
                                        <Skeleton className="h-6 w-16 rounded-full" />
                                    </div>
                                </TableCell>
                                <TableCell className="hidden lg:table-cell"><Skeleton className="h-5 w-40" /></TableCell>
                                <TableCell className="text-right">
                                    <div className="flex gap-1 justify-end">
                                        <Skeleton className="h-7 w-20" />
                                        <Skeleton className="h-7 w-20" />
                                    </div>

                                </TableCell>
                            </TableRow>
                         ))}
                    </TableBody>
                </Table>
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [isClient, setIsClient] = React.useState(false);
  const [attendanceRecords, setAttendanceRecords] = React.useState<AttendanceRecord[]>(initialAttendance)
  const [requests, setRequests] = React.useState<AttendanceChangeRequest[]>(initialRequests)
  const [filteredStatus, setFilteredStatus] = React.useState<AttendanceStatus | 'all' | 'requests'>('all');
  const [timeFrame, setTimeFrame] = React.useState<'today' | 'week' | 'month'>('today');
  const requestsRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  // Use a fixed date for demo purposes to match mock data
  const today = new Date('2024-07-23T12:00:00Z');
  const todayStr = today.toISOString().split("T")[0];

  const { presentCount, absentCount, onLeaveCount, halfDayCount, weeklyOffCount } = React.useMemo(() => {
    let recordsToCount: AttendanceRecord[] = [];

    if (timeFrame === 'today') {
        recordsToCount = attendanceRecords.filter(rec => rec.date === todayStr);
    } else {
        const range = timeFrame === 'week'
          ? { start: startOfWeek(today, { weekStartsOn: 1 }), end: endOfWeek(today, { weekStartsOn: 1 }) }
          : { start: startOfMonth(today), end: endOfMonth(today) };
        
        recordsToCount = attendanceRecords.filter(rec => {
          const recordDate = new Date(rec.date + 'T00:00:00Z'); // Treat date as UTC
          return isWithinInterval(recordDate, range);
        });
    }

    return {
        presentCount: recordsToCount.filter(r => r.status === 'Present').length,
        absentCount: recordsToCount.filter(r => r.status === 'Absent').length,
        onLeaveCount: recordsToCount.filter(r => r.status === 'Leave').length,
        halfDayCount: recordsToCount.filter(r => r.status === 'Half Day').length,
        weeklyOffCount: recordsToCount.filter(r => r.status === 'Weekly Off').length,
    };
  }, [timeFrame, today, todayStr, attendanceRecords]);
  
  const todayAttendance = attendanceRecords.filter(rec => rec.date === todayStr)

  const activeEmployees = employees.filter(e => e.status === 'Active').length;

  const displayedAttendance = React.useMemo(() => {
    if (filteredStatus === 'all' || filteredStatus === 'requests') {
      return todayAttendance;
    }
    return todayAttendance.filter(rec => rec.status === filteredStatus);
  }, [filteredStatus, todayAttendance]);


  const handleApprove = (requestId: string) => {
    const request = requests.find(r => r.id === requestId);
    if (!request) return;

    // Update attendance records state
    setAttendanceRecords(prev => {
        const existing = prev.find(rec => rec.employeeId === request.employeeId && rec.date === request.date);
        if (existing) {
            return prev.map(rec => 
                rec.employeeId === request.employeeId && rec.date === request.date 
                ? { ...rec, status: request.newStatus } 
                : rec
            );
        }
        const employee = employees.find(e => e.id === request.employeeId);
        return [...prev, {
            employeeId: request.employeeId,
            employeeName: employee?.name || 'Unknown',
            date: request.date,
            status: request.newStatus,
        }];
    });
    
    // Update requests state
    setRequests(prevReqs => prevReqs.filter(r => r.id !== requestId));
  };

  const handleReject = (requestId: string) => {
    setRequests(prevReqs => prevReqs.filter(r => r.id !== requestId));
  };

  const handleCardClick = (status: AttendanceStatus | 'all' | 'requests') => {
    setFilteredStatus(status);
    if (status === 'requests' && requestsRef.current) {
      requestsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const getFilterTitle = () => {
    if (filteredStatus === 'all' || filteredStatus === 'requests') return "Today's Attendance Summary";
    if (filteredStatus === 'Half Day') return `Employees Marked as Half Day`;
    return `Employees Marked as ${filteredStatus}`;
  };
  
  const getEmployeeAvatar = (employeeId: string) => {
    const employee = employees.find(e => e.id === employeeId);
    return employee?.avatar || 'https://picsum.photos/seed/placeholder/100/100';
  }

  if (!isClient) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
          <h1 className="text-2xl font-bold tracking-tight">HR Dashboard</h1>
          <Tabs defaultValue="today" onValueChange={(value) => setTimeFrame(value as 'today' | 'week' | 'month')}>
              <TabsList className="grid grid-cols-3">
                  <TabsTrigger value="today">Today</TabsTrigger>
                  <TabsTrigger value="week">This Week</TabsTrigger>
                  <TabsTrigger value="month">This Month</TabsTrigger>
              </TabsList>
          </Tabs>
      </div>

       <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7">
        <Card className="hover:border-primary transition-colors cursor-pointer" onClick={() => handleCardClick('all')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeEmployees}</div>
            <p className="text-xs text-muted-foreground">Total workforce</p>
          </CardContent>
        </Card>
        <Card className="hover:border-green-500 transition-colors cursor-pointer" onClick={() => handleCardClick('Present')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Present</CardTitle>
            <UserCheck className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{presentCount}</div>
            <p className="text-xs text-muted-foreground">in {timeFrame === 'today' ? 'day' : timeFrame}</p>
          </CardContent>
        </Card>
        <Card className="hover:border-red-500 transition-colors cursor-pointer" onClick={() => handleCardClick('Absent')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Absent</CardTitle>
            <UserX className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{absentCount}</div>
            <p className="text-xs text-muted-foreground">in {timeFrame === 'today' ? 'day' : timeFrame}</p>
          </CardContent>
        </Card>
        <Card className="hover:border-orange-500 transition-colors cursor-pointer" onClick={() => handleCardClick('Half Day')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Half Day</CardTitle>
                <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{halfDayCount}</div>
                <p className="text-xs text-muted-foreground">in {timeFrame === 'today' ? 'day' : timeFrame}</p>
            </CardContent>
        </Card>
        <Card className="hover:border-blue-500 transition-colors cursor-pointer" onClick={() => handleCardClick('Leave')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">On Leave</CardTitle>
                <CalendarClock className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{onLeaveCount}</div>
                <p className="text-xs text-muted-foreground">in {timeFrame === 'today' ? 'day' : timeFrame}</p>
            </CardContent>
        </Card>
        <Card className="hover:border-slate-500 transition-colors cursor-pointer" onClick={() => handleCardClick('Weekly Off')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Off</CardTitle>
            <CalendarOff className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{weeklyOffCount}</div>
            <p className="text-xs text-muted-foreground">in {timeFrame === 'today' ? 'day' : timeFrame}</p>
          </CardContent>
        </Card>
        <Card className="bg-yellow-100/50 dark:bg-yellow-900/30 border-yellow-500/50 hover:border-yellow-500 transition-colors cursor-pointer" onClick={() => handleCardClick('requests')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
            <MailQuestion className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{requests.length}</div>
            <p className="text-xs text-muted-foreground">Need approval</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
              <CardTitle>{getFilterTitle()}</CardTitle>
              <CardDescription>
                  A list of employees based on the filter selected above for {new Date(todayStr).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}.
              </CardDescription>
          </CardHeader>
          <CardContent>
              <div className="rounded-md border">
              <Table>
                  <TableHeader>
                      <TableRow>
                          <TableHead>Employee</TableHead>
                          <TableHead className="hidden md:table-cell">Employee ID</TableHead>
                          <TableHead className="text-right">Status</TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {displayedAttendance.length > 0 ? displayedAttendance.map((rec) => (
                          <TableRow key={rec.employeeId}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                    <Avatar className="h-9 w-9">
                                        <AvatarImage src={getEmployeeAvatar(rec.employeeId)} alt={rec.employeeName} />
                                        <AvatarFallback>{rec.employeeName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    <div className="font-medium">{rec.employeeName}</div>
                                </div>
                              </TableCell>
                              <TableCell className="hidden md:table-cell font-mono text-muted-foreground">{rec.employeeId}</TableCell>
                              <TableCell className="text-right">
                                  <span className={cn("inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-medium min-w-[80px]", getStatusClasses(rec.status))}>{rec.status}</span>
                              </TableCell>
                          </TableRow>
                      )) : (
                          <TableRow>
                              <TableCell colSpan={3} className="h-24 text-center">
                                  No records found for "{filteredStatus}" status.
                              </TableCell>
                          </TableRow>
                      )}
                  </TableBody>
              </Table>
              </div>
          </CardContent>
        </Card>
        
        <div ref={requestsRef}>
        <Card>
            <CardHeader>
                <CardTitle>Attendance Change Requests</CardTitle>
                <CardDescription>Review and approve/reject employee attendance change requests.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Employee</TableHead>
                            <TableHead className="hidden sm:table-cell">Date</TableHead>
                            <TableHead>Change</TableHead>
                            <TableHead className="hidden lg:table-cell">Reason</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {requests.length > 0 ? requests.map((req) => (
                            <TableRow key={req.id}>
                                <TableCell>
                                    <div className="font-medium">{req.employeeName}</div>
                                    <div className="text-sm text-muted-foreground md:hidden">{new Date(req.date).toLocaleDateString('en-US')}</div>
                                </TableCell>
                                <TableCell className="hidden sm:table-cell text-muted-foreground">{new Date(req.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}</TableCell>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <span className={cn("inline-flex items-center justify-center rounded-full px-2 py-1 text-xs font-medium min-w-[70px]", getStatusClasses(req.oldStatus as AttendanceStatus))}>{req.oldStatus}</span>
                                        <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0"/>
                                        <span className={cn("inline-flex items-center justify-center rounded-full px-2 py-1 text-xs font-medium min-w-[70px]", getStatusClasses(req.newStatus))}>{req.newStatus}</span>
                                    </div>
                                </TableCell>
                                <TableCell className="hidden lg:table-cell text-muted-foreground max-w-xs truncate" title={req.reason}>{req.reason}</TableCell>
                                <TableCell className="text-right">
                                    <div className="flex gap-1 justify-end">
                                        <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-900/50 dark:text-green-400 dark:hover:text-green-300" onClick={() => handleApprove(req.id)}>Approve</Button>
                                        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/50 dark:text-red-400 dark:hover:text-red-300" onClick={() => handleReject(req.id)}>Reject</Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        )) : (
                            <TableRow>
                                <TableCell colSpan={5} className="h-24 text-center">No pending requests.</TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
                </div>
            </CardContent>
        </Card>
      </div>

      </div>
    </div>
  )
}

    