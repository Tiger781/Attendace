
"use client";

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Send, Bell } from "lucide-react";
import { notifications as initialData } from "@/lib/data";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Notification } from "@/lib/types";

export default function NotificationsPage() {
  const [isClient, setIsClient] = React.useState(false);
  const { toast } = useToast();

  const [title, setTitle] = React.useState("");
  const [message, setMessage] = React.useState("");
  const [notifications, setNotifications] = React.useState<Notification[]>(initialData);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const handleSendNotification = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: "Please fill in both the title and message fields.",
      });
      return;
    }

    const newNotification: Notification = {
      id: `NOTIF${Date.now()}`,
      title,
      message,
      date: new Date().toISOString(),
    };

    setNotifications(prevNotifications => [newNotification, ...prevNotifications]);
    setTitle("");
    setMessage("");

    toast({
      title: "Notification Sent!",
      description: "Your announcement has been sent to all employees.",
    });
  };
  
  const sortedNotifications = [...notifications].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  return (
    <div className="grid md:grid-cols-3 gap-8 items-start">
      <div className="md:col-span-1">
        <Card>
          <CardHeader>
            <CardTitle>Create Notification</CardTitle>
            <CardDescription>
              Send an announcement to all employees.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isClient ? (
              <form className="space-y-4" onSubmit={handleSendNotification}>
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Holiday Announcement"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Enter your message here..."
                    className="min-h-[150px]"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  <Send className="mr-2 h-4 w-4" /> Send Notification
                </Button>
              </form>
            ) : (
              <form className="space-y-4">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-12" />
                  <Skeleton className="h-10 w-full" />
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-[150px] w-full" />
                </div>
                <Skeleton className="h-10 w-full" />
              </form>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="md:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Sent Notifications</CardTitle>
            <CardDescription>
              A history of all announcements sent.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {sortedNotifications.map((notification, index) => (
                <React.Fragment key={notification.id}>
                    <div 
                        className="opacity-0 animation-fade-in-down rounded-lg p-4 transition-all duration-300 hover:bg-muted/50"
                        style={{ animationDelay: `${index * 120}ms` }}
                    >
                        <div className="flex items-start space-x-4">
                            <div className="bg-yellow-100 dark:bg-yellow-900/30 p-3 rounded-full mt-1">
                                <Bell className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                            </div>
                            <div className="flex-1 space-y-1">
                                <div className="flex items-center justify-between">
                                    <p className="text-sm font-medium leading-none">
                                    {notification.title}
                                    </p>
                                    <p className="text-sm text-muted-foreground">
                                    {new Date(notification.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                    </p>
                                </div>
                                <p className="text-sm text-muted-foreground">
                                    {notification.message}
                                </p>
                            </div>
                        </div>
                    </div>
                    {index < sortedNotifications.length - 1 && <Separator className="my-2" />}
                </React.Fragment>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
