
"use client"

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, FileDown, ExternalLink } from "lucide-react";
import { attendanceRecords as data, employees } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import type { AttendanceStatus } from "@/lib/types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn, getStatusClasses } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const getEmployeeAvatar = (employeeId: string) => {
    const employee = employees.find(e => e.id === employeeId);
    return employee?.avatar || 'https://picsum.photos/seed/placeholder/100/100';
}


export default function AttendancePage() {
    const [isClient, setIsClient] = React.useState(false);
    const { toast } = useToast();
    
    const [gSheetUrl, setGSheetUrl] = React.useState("");
    const [isGSheetConnected, setIsGSheetConnected] = React.useState(false);
    const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
    const [isDragging, setIsDragging] = React.useState(false);
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    React.useEffect(() => {
        setIsClient(true);
    }, []);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            setSelectedFile(event.target.files[0]);
             toast({
                title: "File Selected",
                description: event.target.files[0].name,
            });
        }
    };

    const handleUpload = () => {
        if (!selectedFile) {
            fileInputRef.current?.click();
            return;
        }
        // Simulate upload
        toast({
            title: "Upload Successful!",
            description: `${selectedFile.name} has been uploaded.`,
        });
        setSelectedFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = ""; // Reset file input
        }
    };

    const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
        event.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (event: React.DragEvent<HTMLLabelElement>) => {
        event.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (event: React.DragEvent<HTMLLabelElement>) => {
        event.preventDefault();
        setIsDragging(false);
        if (event.dataTransfer.files && event.dataTransfer.files[0]) {
            setSelectedFile(event.dataTransfer.files[0]);
            toast({
                title: "File Selected",
                description: event.dataTransfer.files[0].name,
            });
        }
    };


    const handleConnectGSheet = () => {
        const gsheetRegex = /https:\/\/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/;
        if (gsheetRegex.test(gSheetUrl)) {
            setIsGSheetConnected(true);
            toast({
                title: "Google Sheet Connected!",
                description: "Attendance will now be synced automatically.",
            });
        } else {
            toast({
                variant: "destructive",
                title: "Invalid URL",
                description: "Please enter a valid Google Sheet URL.",
            });
        }
    };

    const handleDisconnectGSheet = () => {
        setIsGSheetConnected(false);
        setGSheetUrl("");
        toast({
            title: "Google Sheet Disconnected",
            description: "Automatic sync has been turned off.",
        });
    };

    const today = new Date().toISOString().split('T')[0];

    if (!isClient) {
        return (
            <div className="space-y-8">
                <Card>
                    <CardHeader>
                        <Skeleton className="h-6 w-1/2" />
                        <Skeleton className="h-4 w-1/3" />
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 gap-8">
                            <div className="space-y-4">
                                <Skeleton className="h-5 w-1/4" />
                                <Skeleton className="h-32 w-full" />
                                <Skeleton className="h-10 w-full" />
                            </div>
                            <div className="space-y-4">
                                <Skeleton className="h-5 w-1/3" />
                                <Skeleton className="h-4 w-full" />
                                <Skeleton className="h-20 w-full" />
                                <Skeleton className="h-10 w-full" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <div className="flex flex-wrap items-center justify-between gap-4">
                            <div>
                                <Skeleton className="h-6 w-48" />
                                <Skeleton className="h-4 w-64 mt-2" />
                            </div>
                            <div className="flex gap-2 items-center">
                                <Skeleton className="h-10 w-32" />
                                <Skeleton className="h-10 w-36" />
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <div className="rounded-md border">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead><Skeleton className="h-5 w-24" /></TableHead>
                                        <TableHead><Skeleton className="h-5 w-24" /></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {[...Array(3)].map((_, i) => (
                                        <TableRow key={i}>
                                            <TableCell>
                                                <div className="flex items-center gap-3">
                                                    <Skeleton className="h-9 w-9 rounded-full" />
                                                    <div>
                                                        <Skeleton className="h-5 w-32" />
                                                        <Skeleton className="h-4 w-24 mt-1" />
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Skeleton className="h-6 w-20 rounded-full" />
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-8">
             <Card>
                <CardHeader>
                    <CardTitle>Attendance Management</CardTitle>
                    <CardDescription>Upload attendance sheets and view daily records.</CardDescription>
                </CardHeader>
                <CardContent>
                   <div className="grid md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                            <h3 className="font-semibold text-lg">Upload Attendance File</h3>
                            <Label
                                htmlFor="attendance-file"
                                className={cn(
                                    "block p-6 border-2 border-dashed rounded-lg text-center space-y-2 transition-colors cursor-pointer",
                                    isDragging ? "border-primary bg-primary/10" : "hover:border-primary"
                                )}
                                onDragOver={handleDragOver}
                                onDragLeave={handleDragLeave}
                                onDrop={handleDrop}
                            >
                                <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                                <span className="block text-sm font-medium text-primary">
                                    {selectedFile ? selectedFile.name : 'Click to upload or drag and drop'}
                                </span>
                                <p className="text-xs text-muted-foreground">XLS, XLSX, or CSV up to 10MB</p>
                                <Input 
                                    id="attendance-file" 
                                    type="file" 
                                    className="sr-only" 
                                    onChange={handleFileChange}
                                    ref={fileInputRef}
                                    accept=".xls,.xlsx,.csv"
                                />
                            </Label>
                            <Button className="w-full" onClick={handleUpload}>
                                <Upload className="mr-2 h-4 w-4" /> Upload File
                            </Button>
                        </div>
                        <div className="space-y-4">
                            <h3 className="font-semibold text-lg">Integrate with Google Sheets</h3>
                            <p className="text-sm text-muted-foreground">Automatically sync attendance from a Google Sheet. This requires one-time setup.</p>
                             <div className="p-6 border rounded-lg bg-secondary/30 dark:bg-secondary/20">
                                 <div className="space-y-2">
                                    <Label htmlFor="gsheet-url">Google Sheet URL</Label>
                                    <Input 
                                        id="gsheet-url" 
                                        placeholder="https://docs.google.com/spreadsheets/d/..."
                                        value={gSheetUrl}
                                        onChange={(e) => setGSheetUrl(e.target.value)}
                                        disabled={isGSheetConnected}
                                    />
                                </div>
                             </div>
                            {isGSheetConnected ? (
                                <Button variant="destructive" className="w-full" onClick={handleDisconnectGSheet}>
                                    <ExternalLink className="mr-2 h-4 w-4" /> Disconnect Google Sheet
                                </Button>
                            ) : (
                                <Button variant="secondary" className="w-full" onClick={handleConnectGSheet}>
                                    <ExternalLink className="mr-2 h-4 w-4" /> Connect Google Sheet
                                </Button>
                            )}
                        </div>
                   </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <div className="flex flex-wrap items-center justify-between gap-4">
                        <div>
                            <CardTitle>Attendance for {new Date(today).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</CardTitle>
                            <CardDescription>A summary of today's attendance records.</CardDescription>
                        </div>
                        <div className="flex gap-2 items-center">
                            <Input type="date" defaultValue={today} className="w-auto" />
                            <Button variant="outline">
                                <FileDown className="mr-2 h-4 w-4" /> Export Report
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Employee</TableHead>
                                    <TableHead>Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {data.filter(rec => rec.date === today).map((record) => (
                                    <TableRow key={record.employeeId}>
                                        <TableCell>
                                             <div className="flex items-center gap-3">
                                                <Avatar className="h-9 w-9">
                                                    <AvatarImage src={getEmployeeAvatar(record.employeeId)} alt={record.employeeName} />
                                                    <AvatarFallback>{record.employeeName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                                </Avatar>
                                                <div>
                                                    <div className="font-medium">{record.employeeName}</div>
                                                    <div className="text-sm text-muted-foreground font-mono">{record.employeeId}</div>
                                                </div>
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                            <span
                                              className={cn(
                                                "inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-medium min-w-[80px]",
                                                getStatusClasses(record.status as AttendanceStatus)
                                              )}
                                            >
                                              {record.status}
                                            </span>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
