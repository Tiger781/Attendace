
"use client";

import * as React from "react";
import { getEmployeeData } from "@/lib/data";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { AttendanceStatus } from "@/lib/types";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function EmployeeDashboard() {
    const [currentDate, setCurrentDate] = React.useState(new Date(2024, 6, 1)); // Start with July 2024
    const attendanceData = getEmployeeData('EMP002'); // Mock data for one employee
    const { toast } = useToast();

    const [selectedDay, setSelectedDay] = React.useState<number | null>(null);
    const [isDialogOpen, setIsDialogOpen] = React.useState(false);

    const handlePrevMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    };
    
    const handleDayClick = (day: number) => {
        setSelectedDay(day);
        setIsDialogOpen(true);
    };

    const handleSendRequest = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        // In a real app, this would send data to a backend.
        // For this demo, we'll just show a confirmation toast.
        setIsDialogOpen(false);
        toast({
            title: "Request Sent!",
            description: "Your request has been sent to HR for approval.",
        });
    };

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0=Sun, 1=Mon, ...
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const summary = {
        present: 0,
        absent: 0,
        halfday: 0,
        leave: 0,
        weeklyoff: 0,
    };
    
    const statusColorClasses: Record<AttendanceStatus, string> = {
        'Present': 'bg-green-600 text-white border-green-600',
        'Absent': 'bg-red-600 text-white border-red-600 font-semibold',
        'Half Day': 'bg-yellow-500 text-white border-yellow-500',
        'Leave': 'bg-blue-500 text-white border-blue-500',
        'Weekly Off': 'bg-gray-400 text-white border-gray-400',
    };

    const calendarDays = [];
    // Add empty cells for padding before the first day
    for (let i = 0; i < firstDayOfMonth; i++) {
        calendarDays.push(<div key={`empty-${i}`} />);
    }

    // Add day cells for the current month
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        let status: AttendanceStatus | undefined = attendanceData[dateStr as keyof typeof attendanceData];
        const dayOfWeek = new Date(year, month, day).getDay();

        if (!status && (dayOfWeek === 0 || dayOfWeek === 6)) { // Sunday or Saturday
            status = 'Weekly Off';
        }
        
        if (status) {
            const normalizedStatus = status.toLowerCase().replace(/ /g, '') as keyof typeof summary;
            if (summary.hasOwnProperty(normalizedStatus)) {
                summary[normalizedStatus]++;
            }
        }

        calendarDays.push(
            <button 
                key={day} 
                className={cn(
                    "aspect-square rounded-lg text-sm flex items-center justify-center font-medium cursor-pointer transition-all duration-200 ease-in-out border",
                    "hover:scale-105 hover:shadow-md focus:outline-none focus:scale-105 focus:shadow-md focus:ring-2 focus:ring-ring focus:z-10",
                    status ? statusColorClasses[status] : "bg-transparent border-border hover:bg-accent",
                )} 
                onClick={() => handleDayClick(day)}
            >
                {day}
            </button>
        );
    }

    const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const selectedDate = selectedDay ? new Date(year, month, selectedDay) : new Date();
    const currentStatus = attendanceData[selectedDate.toISOString().split('T')[0] as keyof typeof attendanceData] || 'N/A';

    type SummaryKey = keyof typeof summary;

    const summaryItems: { label: string; key: SummaryKey; dotClass: string }[] = [
        { label: 'Present', key: 'present', dotClass: 'bg-green-600' },
        { label: 'Absent', key: 'absent', dotClass: 'bg-red-600' },
        { label: 'Half Day', key: 'halfday', dotClass: 'bg-yellow-500' },
        { label: 'Leave', key: 'leave', dotClass: 'bg-blue-500' },
        { label: 'Weekly Off', key: 'weeklyoff', dotClass: 'bg-gray-400' },
    ];

    return (
        <>
            <div className="space-y-6">
                <header className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold tracking-tight">My Attendance</h1>
                        <p className="text-muted-foreground">View your monthly attendance record.</p>
                    </div>
                </header>

                <Card>
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <Button variant="outline" size="icon" onClick={handlePrevMonth} aria-label="Previous month">
                                <ChevronLeft className="h-4 w-4" />
                            </Button>
                            <span className="text-lg font-semibold">{currentDate.toLocaleString('en-US', { month: 'long', year: 'numeric' })}</span>
                            <Button variant="outline" size="icon" onClick={handleNextMonth} aria-label="Next month">
                                <ChevronRight className="h-4 w-4" />
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-7 text-center text-sm font-medium text-muted-foreground mb-4">
                            {weekdays.map(day => <span key={day}>{day}</span>)}
                        </div>

                        <div className="grid grid-cols-7 gap-2">
                            {calendarDays}
                        </div>
                    </CardContent>
                </Card>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                     {summaryItems.map(item => (
                        <Card key={item.key}>
                            <CardContent className="p-4">
                                <div className="flex items-center gap-2">
                                     <span className={cn("h-2 w-2 rounded-full", item.dotClass)}></span>
                                     <span className="text-sm font-medium text-muted-foreground">{item.label}</span>
                                </div>
                                <p className="text-2xl font-bold mt-1">{summary[item.key]}</p>
                            </CardContent>
                        </Card>
                     ))}
                </div>
            </div>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Request Attendance Change</DialogTitle>
                        <DialogDescription>
                            Request to change your attendance status for {selectedDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}.
                            Your current status is marked as <strong>{currentStatus}</strong>.
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSendRequest}>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="new-status" className="text-right">New Status</Label>
                                <Select required name="newStatus">
                                    <SelectTrigger id="new-status" className="col-span-3">
                                        <SelectValue placeholder="Select a status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Present">Present</SelectItem>
                                        <SelectItem value="Absent">Absent</SelectItem>
                                        <SelectItem value="Half Day">Half Day</SelectItem>
                                        <SelectItem value="Leave">Leave</SelectItem>
                                        <SelectItem value="Weekly Off">Weekly Off</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="reason" className="text-right">Reason</Label>
                                <Textarea id="reason" name="reason" placeholder="Please provide a reason for the change." className="col-span-3" required/>
                            </div>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                            <Button type="submit">Send Request</Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </>
    );
}
