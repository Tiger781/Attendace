"use client";

import { AppLayout } from "@/components/layout/app-layout";
import { LayoutDashboard, Bell, User } from "lucide-react";

const navItems = [
    { href: "/employee/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/employee/notifications", label: "Notifications", icon: Bell },
    { href: "/employee/profile", label: "Profile", icon: User },
];

export default function EmployeeLayout({ children }: { children: React.ReactNode }) {
    return <AppLayout navItems={navItems}>{children}</AppLayout>;
}
