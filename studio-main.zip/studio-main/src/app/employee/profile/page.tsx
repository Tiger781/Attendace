
"use client";

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { employees } from "@/lib/data";
import { Pen } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

function EmployeeProfileSkeleton() {
    return (
        <Card className="max-w-4xl mx-auto">
            <CardHeader>
                <Skeleton className="h-7 w-1/4" />
                <Skeleton className="h-4 w-2/3 mt-1" />
            </CardHeader>
            <form>
                <CardContent className="space-y-8">
                    <div className="flex items-center gap-6">
                        <Skeleton className="h-24 w-24 rounded-full border" />
                        <div className="space-y-2">
                            <Skeleton className="h-8 w-48" />
                            <Skeleton className="h-5 w-32" />
                            <Skeleton className="h-4 w-24" />
                        </div>
                    </div>
                    <Separator />
                    <div className="grid md:grid-cols-2 gap-6">
                        {[...Array(6)].map((_, i) => (
                            <div className="space-y-2" key={i}>
                                <Skeleton className="h-4 w-20" />
                                <Skeleton className="h-10 w-full" />
                            </div>
                        ))}
                    </div>
                </CardContent>
                <CardFooter className="border-t pt-6">
                    <div className="flex justify-end gap-2 w-full">
                        <Skeleton className="h-10 w-24" />
                        <Skeleton className="h-10 w-32" />
                    </div>
                </CardFooter>
            </form>
        </Card>
    );
}

export default function ProfilePage() {
  const [isClient, setIsClient] = React.useState(false);
  const { toast } = useToast();
  
  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const user = employees.find(e => e.id === 'EMP002'); // Mocking logged in user

  // State for form fields
  const [name, setName] = React.useState(user?.name || "");
  const [email, setEmail] = React.useState("tabrej.s@attendhr.com"); // Mock email

  // Reset form when user data loads
  React.useEffect(() => {
      if (user) {
          setName(user.name);
      }
  }, [user]);

  const handleSaveChanges = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      // In a real app, you'd save this to a backend.
      console.log("Saving changes:", { name, email });
      toast({
          title: "Profile Updated",
          description: "Your changes have been saved successfully.",
      });
  };

  const handleCancel = () => {
      if(user) setName(user.name);
      setEmail("tabrej.s@attendhr.com");
       toast({
          title: "Changes Discarded",
          description: "Your changes have been discarded.",
      });
  };

  if (!isClient) {
    return <EmployeeProfileSkeleton />;
  }

  if (!user) {
    return <div>User not found.</div>;
  }

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>My Profile</CardTitle>
        <CardDescription>
          Your personal and employment details. Some fields are not editable.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSaveChanges}>
        <CardContent className="space-y-8">
            <div className="flex items-center gap-6">
            <div className="relative">
                <Avatar className="h-24 w-24 border">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <Button variant="outline" size="icon" className="absolute -bottom-2 -right-2 rounded-full bg-background hover:bg-muted h-8 w-8">
                    <Pen className="h-4 w-4"/>
                    <span className="sr-only">Edit Profile Picture</span>
                </Button>
            </div>
            <div className="space-y-1">
                <h2 className="text-2xl font-bold tracking-tight">{user.name}</h2>
                <p className="text-muted-foreground">{user.department}</p>
                <p className="text-sm text-muted-foreground">{user.location}</p>
            </div>
            </div>

            <Separator />

            <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
                <Label htmlFor="employeeId">Employee ID</Label>
                <Input id="employeeId" value={user.id} readOnly disabled />
            </div>
            <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number</Label>
                <Input id="mobile" value={user.mobile} readOnly disabled />
                <p className="text-xs text-muted-foreground">Mobile number cannot be changed. Please contact HR for assistance.</p>
            </div>
            <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input id="department" value={user.department} readOnly disabled />
            </div>
            <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" value={user.location} readOnly disabled />
            </div>
            </div>

        </CardContent>
        <CardFooter className="border-t pt-6">
            <div className="flex justify-end gap-2 w-full">
                <Button type="button" variant="outline" onClick={handleCancel}>Cancel</Button>
                <Button type="submit">Save Changes</Button>
            </div>
        </CardFooter>
      </form>
    </Card>
  );
}
