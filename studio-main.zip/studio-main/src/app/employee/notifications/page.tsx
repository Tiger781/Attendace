
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell, AlertTriangle } from "lucide-react";
import { notifications as data } from "@/lib/data";
import { Separator } from "@/components/ui/separator";
import React from "react";

export default function NotificationsPage() {
  const sortedNotifications = [...data].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center gap-4">
            <AlertTriangle className="h-8 w-8 text-yellow-600 dark:text-yellow-400" />
            <div>
                <CardTitle>Important Notifications</CardTitle>
                <CardDescription>
                Announcements from HR. These are mandatory to read.
                </CardDescription>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {sortedNotifications.map((notification, index) => (
            <React.Fragment key={notification.id}>
                <div 
                    className="opacity-0 animation-fade-in-down rounded-lg p-4 transition-all duration-300 hover:bg-muted/50"
                    style={{ animationDelay: `${index * 120}ms` }}
                >
                    <div className="flex items-start space-x-4">
                        <div className="bg-yellow-100 dark:bg-yellow-900/30 p-3 rounded-full mt-1">
                            <Bell className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                        </div>
                        <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                                <p className="text-sm font-medium leading-none">
                                {notification.title}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                {new Date(notification.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                                </p>
                            </div>
                            <p className="text-sm text-muted-foreground">
                                {notification.message}
                            </p>
                        </div>
                    </div>
                </div>
                {index < sortedNotifications.length - 1 && <Separator className="my-2" />}
            </React.Fragment>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
