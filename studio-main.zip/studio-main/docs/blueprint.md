# **App Name**: SynergyHR

## Core Features:

- HR Login & Access: Secure HR/Admin login via Mobile Number + OTP or Admin ID + Password.
- Employee Login & Access: Secure Employee login via Employee ID + OTP or Mobile Number + OTP.
- Attendance Management (HR): HR Excel/Google Sheet upload for attendance. Supports Employee ID, Name, Date, Status (Present/Absent/Half Day/Leave). Auto-sync and employee-wise attendance update upon upload.
- Attendance View (Employee): Read-only month-wise calendar and date-wise list view of individual employee attendance. No edit option available.
- Notification System (HR): HR creates and sends mandatory read announcements/notices/messages to all employees (seen status optional).
- Employee Management (HR): HR adds/removes employees, including fields: Employee ID, Name, Mobile Number, Department, Location. Includes employee block/deactivate option.
- Reports & Dashboard (HR): Monthly attendance summary, date-wise attendance. Export attendance reports (Excel/PDF).

## Style Guidelines:

- Primary color: Deep blue (#2962FF) to convey professionalism and trust.
- Background color: Light gray (#F0F4F8), a very desaturated version of the primary hue, creating a clean, neutral backdrop.
- Accent color: Soft green (#76FF03), an analogous color to the primary hue to provide highlights and signify positive actions such as 'present'.
- Body and headline font: 'PT Sans' (sans-serif) provides a balance of modernity and approachability suitable for both.
- Use clear and professional icons for attendance statuses, notifications, and employee management actions.
- Clean and intuitive layout for both HR and employee apps, focusing on ease of navigation and data clarity.
- Subtle transitions and loading animations to provide feedback without being distracting.